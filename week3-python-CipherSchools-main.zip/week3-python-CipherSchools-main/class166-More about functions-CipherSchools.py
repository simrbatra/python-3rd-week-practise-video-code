# what are doc strings
# how to write docstring
# how to see docstring
# what is help function

def add(a,b):
    ''' this function takes 2 numbers and return their sum'''
    return a+b

# print(add.__doc__)

# len , sum , max , min , sorted
# print(len.__doc__)

# print(sum.__doc__)
# sum
print(help(sum))