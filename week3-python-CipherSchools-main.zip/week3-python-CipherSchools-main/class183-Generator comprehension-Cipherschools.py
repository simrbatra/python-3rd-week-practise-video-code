square = (i**2 for i in range(1,11))

print(next(square))
print(next(square))
print(next(square))


for num in square:
    print(num)

for num in square:
    print(num)